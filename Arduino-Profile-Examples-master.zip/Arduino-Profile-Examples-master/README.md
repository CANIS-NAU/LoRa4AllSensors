Dragino bootloader,board profile,examples for Arduino IDE
===============
This repository include the bootloader, board profile needed by Dragino when using Arduino. it also include some examples. 
Users don't need to download the source here. They can use the Arduino Board Manager to install this source in Arduino IDE. 
reference link: [How to add board profile](http://wiki.dragino.com/index.php?t